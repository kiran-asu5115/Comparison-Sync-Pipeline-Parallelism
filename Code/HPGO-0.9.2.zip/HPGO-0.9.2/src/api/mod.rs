/// HPGO API: Python3
pub mod pylib;

/// HPGO API: C
pub mod capi;
