use environment::network::*;

// Default constant for NVLink
pub const BANDWIDTH_NVLINK_P2P: f64 = 25.0 * GIGABYTE;
